if(document.readyState !== "loading") {
    initializeCode();
  } else {
    document.addEventListener("DOMContentLoaded", function() {
        initializeCode();
    })
  }
  

async function initializeCode() {
    if(localStorage.getItem("auth_token") == null){
        window.location.href = "login.html"
    }

    let logout = document.getElementById("logout");
    logout.addEventListener("click", async function(event){
        localStorage.removeItem("auth_token")
        window.location.href = "login.html"
      })

}