import React from 'react';
import CSS from "csstype";

type IItem = {
    id: string,
    text: string,
    clicked: boolean
}

interface IList {
    header: string,
    items: IItem[],
}

const MyList: React.FC<IList> = ({header, items}) => {
    const lineStyle: CSS.Properties = { // https://oida.dev/typescript-react/styles/
        textDecoration: "line-through"
      };
    return (
        <div>
            <h1>{header}</h1>
            <ol>
                {items.map((item) =>(
                    <li onClick={() => {item.clicked = true}} style={item.clicked ? lineStyle : undefined}>{item.text}</li>
                ))}
            </ol>
        </div>
    )
}


export default MyList