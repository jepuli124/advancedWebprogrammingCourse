import React from 'react';


interface IList {
    string: string
}

const MyList: React.FC<IList> = ({string}) => {
    return (
        <div>
            <p>{string}</p>
        </div>
    )
}


export default MyList