import React from 'react';
import './MyList'
import MyList from './MyList';

interface IMyContainer {
    myLists: {
        string: string
    }[]
}

const MyContainer: React.FC<IMyContainer> = ({myLists}) => {
    return (
        <div>
            {myLists.map((myList) =>(
                <MyList string={myList.string}/>
            ))}
            
        </div>
    )
}


export default MyContainer