// import { useState } from 'react'
// import reactLogo from './assets/react.svg'
// import viteLogo from '/vite.svg'
import './App.css'
import './components/MyContainer'
import MyContainer from './components/MyContainer'


function App() {
  // const [count, setCount] = useState(0)

  return (
    <div>
      <h1>Hello World!</h1>
      <MyContainer myLists={[{string: "b"}, {string: "o"}, {string: "i"},]}></MyContainer>
    </div>
  )
}

export default App
