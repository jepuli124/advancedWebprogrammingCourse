import React from 'react';

type IItem = {
    id: string,
    text: string
}

interface IList {
    header: string,
    items: IItem[],
}

const MyList: React.FC<IList> = ({header, items}) => {
    return (
        <div>
            <h1>{header}</h1>
            <ol>
                {items.map((item) =>(
                    <li>{item.text}</li>
                ))}
            </ol>
        </div>
    )
}


export default MyList