import { useState } from 'react'
import React from 'react';
import './MyList'
import MyList from './MyList';

type TItem = {
    id: string,
    text: string
}

interface IMyContainer {
    items: TItem[]
}


const MyContainer: React.FC<IMyContainer> = () => {
    
    const [items, setItems] = useState<TItem[]>()

    //setItems(myCont.items)
    if (items == undefined){
         return (
         <div>
            <textarea></textarea>
            <button></button>
        </div>)
    }

    const handleItems = () => {
        const inputArea: HTMLInputElement = document.getElementById("inputTextArea") as HTMLInputElement
        const newItems: TItem[] = items

        const temp: string = inputArea.value

        
        const newItem: TItem = {
            id: "142513",
            text: temp,
        }
        newItems.push(newItem)
        setItems(newItems)
    }

    return (
        <div>
            <MyList header={"header"} items={items}/>
            <textarea id="inputTextArea"></textarea>
            <button onClick={handleItems}></button>
        </div>
    )
}


export default MyContainer