if(document.readyState !== "loading") {
    initializeCode();
  } else {
    document.addEventListener("DOMContentLoaded", function() {
        initializeCode();
    })
  }
  

  


function initializeCode() {

    wikiItem();



}

function wikiItem(){

    headDiv = document.createElement("div");
    headDiv.class = "wiki-item";

    headtext = document.createElement("h1");
    headtext.class = "wiki-header";
    headtext.value = "Breed X";

    contentDiv = document.createElement("div");
    contentDiv.class = "wiki-content";

    maintext = document.createElement("p");
    maintext.class = "wiki-text";
    maintext.value = "Some text about this breed";

    imgcontainer = document.createElement("div");
    imgcontainer.class = "img-container";

    dogImg = document.createElement("img");
    dogImg.class = "wiki-img";
    dogImg.src = "";

    imgcontainer.appendChild(dogImg);
    contentDiv.appendChild(maintext);
    contentDiv.appendChild(imgcontainer);
    headDiv.appendChild(headtext);
    headDiv.appendChild(contentDiv);

    ogbody = document.getElementById("ogbody");
    ogbody.appendChild(headDiv);

}